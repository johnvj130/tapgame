import 'dart:async';
import 'package:flutter/material.dart';

void main() {
  runApp(const TapGame());
}

class TapGame extends StatelessWidget {
  const TapGame({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const GameScreen(),
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  int score = 0;
  int timeLeft = 10;
  Timer? timer;
  bool isGameRunning = false;

  void startGame() {
    score = 0;
    timeLeft = 10;
    isGameRunning = true;

    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() {
        timeLeft--;
        if (timeLeft == 0) {
          t.cancel();
          isGameRunning = false;
          showGameOver();
        }
      });
    });

    setState(() {});
  }

  void showGameOver() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Game Over"),
        content: Text("Your Score: $score"),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              startGame();
            },
            child: const Text("Restart"),
          )
        ],
      ),
    );
  }

  void tap() {
    if (isGameRunning) {
      setState(() {
        score++;
      });
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tap Game"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Time: $timeLeft", style: const TextStyle(fontSize: 28)),
            const SizedBox(height: 20),
            Text("Score: $score", style: const TextStyle(fontSize: 32)),
            const SizedBox(height: 40),
            GestureDetector(
              onTap: tap,
              child: Container(
                padding: const EdgeInsets.all(40),
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  "TAP!",
                  style: TextStyle(fontSize: 24, color: Colors.white),
                ),
              ),
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: startGame,
              child: const Text("Start Game"),
            )
          ],
        ),
      ),
    );
  }
}
