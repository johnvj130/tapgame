# Tap Game (Flutter)

Simple tap-based game built with Flutter.

## Run
flutter pub get
flutter run
